# 2021-2-T8-AULA
Exemplos das aulas
